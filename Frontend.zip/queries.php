<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Covid-19 Website Design Tutorial</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="assignment1.css">

</head>

<!-- header section starts  -->

<header>

    <a href="#" class="logo">c<span class="fas fa-virus"></span>VID-19 Analysis</a>

</header>


<body>
<br>
<div class="Queries"> 
		<h5>Q. Show the details of the number of samples tested across each timestamp</h5>
		<br> SELECT distinct UpdatedTimeStamp, TotalSamplesTested
			FROM icmrtestingdata where TotalSamplesTested&lt;&gt;&quot;&quot;;

</div>
<br>
<table>
<tr>
<th>Update time stamp</th>
<th>Total smaples tested</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT  distinct UpdatedTimeStamp, TotalSamplesTested FROM icmrtestingdata ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
			echo "<tr><td>";
			echo $row['UpdatedTimeStamp'];
			echo "</td><td>";
			echo $row['TotalSamplesTested'];
			echo "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
<br>

<div class="Queries"> 
		<h5>Q. Display the states, gender affected and the confirmed cases in their respective states where confirmed cases are more than 100</h5>
		<br> SSELECT DISTINCT State,Gender,Confirmed FROM death_and_recovery INNER JOIN statewisedata ON death_and_recovery.State=statewisedata.State_UT WHERE Confirmed>100;

</div>
<br>
<table>
<tr>
<th>State</th>
<th>Gender</th>
<th>Confirmed</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql ="SELECT DISTINCT State,Gender,Confirmed FROM death_and_recovery INNER JOIN statewisedata ON death_and_recovery.State=statewisedata.State_UT WHERE Confirmed>100 ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
			echo "<tr><td>";
			echo $row['State'];
			echo "</td><td>";
			echo $row['Gender'];
			echo "</td><td>";
			echo $row['Confirmed'];
			echo "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>

<br>
<div class="Queries"> 
		<h5>Q. Show the state, hospitals and beds available where beds and hospitals available are more than 1000</h5>
		<br> SELECT State_UT,Hospitals_Available,Beds_Available
FROM hospitalbeds WHERE Hospitals_Available>1000 AND Population_beds>1000;

</div>
<br>
<table>
<tr>
<th>State</th>
<th>Hospitals_Available</th>
<th>Beds_Available</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT State_UT,Hospitals_Available,Beds_Available
FROM hospitalbeds WHERE Hospitals_Available>1000 AND Population_beds>1000";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
			echo "<tr><td>";
			echo $row['State_UT'];
			echo "</td><td>";
			echo $row['Hospitals_Available'];
			echo "</td><td>";
			echo $row['Beds_Available'];
			echo "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
<br>

<div class="Queries"> 
		<h5>Q. Display the states which collected more than 1000 samples in day.</h5>
		<br> SELECT statewisedata.sno as 'Serial No.', statewisedata.State_UT,icmrtestingdata.TotalSamplesTested
FROM icmrtestingdata
 RIGHT join statewisedata
on statewisedata.sno=icmrtestingdata.sno
WHERE icmrtestingdata.TotalSamplesTested>1000;


</div>
<br>
<table>
<tr>
<th>Serial No.</th>
<th>State_UT</th>
<th>TotalSamplesTested</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT statewisedata.sno as 'Serial No.', statewisedata.State_UT,icmrtestingdata.TotalSamplesTested
FROM icmrtestingdata
 RIGHT join statewisedata
on statewisedata.sno=icmrtestingdata.sno
WHERE icmrtestingdata.TotalSamplesTested>1000";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
			echo "<tr><td>";
			echo $row['Serial No.'];
			echo "</td><td>";
			echo $row['State_UT'];
			echo "</td><td>";
			echo $row['TotalSamplesTested'];
			echo "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
<br>


<div class="Queries"> 
		<h5>Q. Retrieve the state with maximum population, their density per sq km and group by descending order with respect to population</h5>
		<br>SELECT Rank, State_UT, Population, Density_per_sqkm
FROM populationdistribution_2011census_
WHERE (State_UT, Population) IN
(SELECT State_UT, MAX(Population)
FROM populationdistribution_2011census_
GROUP BY Population);


</div>
<br>
<table>
<tr>
<th>Rank</th>
<th>State_UT</th>
<th>Population</th>
<th>Density_per_sqkm</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Rank, State_UT, Population, Density_per_sqkm
FROM populationdistribution_2011census_
WHERE (State_UT, Population) IN
(SELECT State_UT, MAX(Population)
FROM populationdistribution_2011census_
GROUP BY Population)";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
			echo "<tr><td>";
			echo $row['Rank'];
			echo "</td><td>";
			echo $row['State_UT'];
			echo "</td><td>";
			echo $row['Population'];
			echo "</td><td>";
			echo $row['Density_per_sqkm'];
			echo "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
<br>

<div class="Queries"> 
		<h5>Q.Display the hospital beds along with their location where patients have recovered from covid-19 and those beds are made available to the needy patients waiting in the queue to get admitted.</h5>
		<br> SELECT death_and_recovery.Patient_status as 'Patient Status', death_and_recovery.State,death_and_recovery.City,hospitalbeds.Beds_Available
FROM death_and_recovery
 RIGHT join hospitalbeds
ON death_and_recovery.State=hospitalbeds.State_UT
WHERE death_and_recovery.Patient_status='Recovered';
</div>
<br>

<table>
<tr>
<th>Patient status</th>
<th>State</th>
<th>City</th>
<th>Beds_Available</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT death_and_recovery.Patient_status as 'Patient Status', death_and_recovery.State,death_and_recovery.City,hospitalbeds.Beds_Available
FROM death_and_recovery
 RIGHT join hospitalbeds
ON death_and_recovery.State=hospitalbeds.State_UT
WHERE death_and_recovery.Patient_status='Recovered'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
			echo "<tr><td>";
			echo $row['Patient Status'];
			echo "</td><td>";
			echo $row['State'];
			echo "</td><td>";
			echo $row['City'];
			echo "</td><td>";
			echo $row['Beds_Available'];
			echo "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
<br>

<div class="Queries"> 
		<h5>Q.Display the total number of people in assam who have recovered.</h5>
		<br> SELECT COUNT(Patient_status)
FROM death_and_recovery
WHERE Patient_status="Recovered" And State="Assam";

</div>
<br>

<table>
<tr>
<th>Count(Patient status)</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT COUNT(Patient_status)
FROM death_and_recovery
WHERE Patient_status='Recovered' And State='Assam'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
			echo "<tr><td>";
			echo $row['COUNT(Patient_status)'];
			echo "</td></tr>";
			}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
<br>



<div class="Queries"> 
		<h5>Q. Display the number of patients who have recovered along with their dates.</h5>
		<br> SELECT Daily_confirmed as 'Dates', Total_recovered, status
 from casetime join datewisepatients 
 on datewisepatients.Date=casetime.Daily_confirmed
  where status='Recovered';

</div>
<br>

<table>
<tr>
<th>Dates</th>
<th>Total_recovered</th>
<th>Status</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Daily_confirmed as 'Dates', Total_recovered, status
 from casetime join datewisepatients 
 on datewisepatients.Date=casetime.Daily_confirmed
  where status='Recovered'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
			echo "<tr><td>";
			echo $row['Dates'];
			echo "</td><td>";
			echo $row['Total_recovered'];
			echo "</td><td>";
			echo $row['status'];
			echo "</td></tr>";
			}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
<br>


<div class="Queries"> 
		<h5>Q. Show the ratio of male and female to the whole population for all states.</h5>
		<br> SELECT sum(Male)/sum(population) as male_ratio,
	sum(Female)/sum(population) as female_ratio
	FROM populationdistribution_2011census_;


</div>
<br>

<table>
<tr>
<th>Male</th>
<th>Female</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT sum(Male)/sum(population) as male_ratio,
	sum(Female)/sum(population) as female_ratio
	FROM populationdistribution_2011census_";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
			echo "<tr><td>";
			echo $row['male_ratio'];
			echo "</td><td>";
			echo $row['female_ratio'];
			echo "</td></tr>";
			}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
<br>


<div class="Queries"> 
		<h5>Q.Find the 3rd minimum population in the population_distribution table and also find out the State and area per sq km.</h5>
		<br> SELECT DISTINCT State_UT,Population, Area_sqkm
from populationdistribution_2011census_ p1 where 3 = (select count (distinct Population) from populationdistribution_2011census_  p2 where p1.Population >= p2.Population);



</div>
<br>

<table>
<tr>
<th>State_UT</th>
<th>Population</th>
<th>Area_sqkm</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT DISTINCT State_UT,Population, Area_sqkm
from populationdistribution_2011census_ p1 where 3 = (select count(distinct Population) from populationdistribution_2011census_  p2 where p1.Population >= p2.Population)";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
			echo "<tr><td>";
			echo $row['State_UT'];
			echo "</td><td>";
			echo $row['Population'];
			echo "</td><td>";
			echo $row['Area_sqkm'];
			echo "</td></tr>";
			}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
<br>




<div class="Queries"> 
		<h5>Q.Display the total confirmed cases till 31-March in Maharashtra.</h5>
		<br> SELECT statewisedata.Active,datewisepatients.Date,statewisedata.State_UT FROM statewisedata, datewisepatients WHERE MOD (datewisepatients.Date,2) =0 ORDER BY datewisepatients.Date;;

</div>
<br>

<table>
<tr>
<th>Confirmed</th>
<th>State_UT</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Confirmed,State_UT
FROM statewisedata
WHERE statewisedata.Last_updad_time <='31/03/2020 23:07:28' AND statewisedata.State_UT='Maharashtra';
";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
			echo "<tr><td>";
			echo $row['Confirmed'];
			echo "</td><td>";
			echo $row['State_UT'];
			echo "</td></tr>";
			}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
<br>






</body>
</html>
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 


